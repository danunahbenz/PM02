﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void HoldButton_PreviewMouseLeftButtonDown(object sender, RoutedEventArgs e)
        {
            txtPassword.Text = pboxPassword.Password;
            pboxPassword.Visibility = Visibility.Collapsed;
        }
        private void HoldButton_PreviewMouseLeftButtonUp(object sender, RoutedEventArgs e)
        {
            txtPassword.Text = null;
            pboxPassword.Visibility = Visibility.Visible;
        }
        private void btnAuth_Click(object sender, RoutedEventArgs e)
        {
            using ( var db = new PM02ZhuykovAEntities())
            {
                var usern = db.Пользователи.FirstOrDefault(uch => uch.Логин == txtLogin.Text && uch.Пароль == pboxPassword.Password);
                if (usern == null) MessageBox.Show("Неверно введен логин или пароль");
                else MessageBox.Show("Добро пожал");
                if (usern.ID_Роли == 1)
                {
                    laborant laborant = new laborant();
                    laborant.Show();
                    this.Close();
                }
                if (usern.ID_Роли == 2)
                {
                    labissledovatel labissledovatel = new labissledovatel();
                    labissledovatel.Show();
                    this.Close();
                }
                if (usern.ID_Роли == 3)
                {
                    buh buh = new buh();
                    buh.Show();
                    this.Close();
                }
                if (usern.ID_Роли == 4)
                {
                    admin admin = new admin();
                    admin.Show();
                    this.Close();
                }
            }

        }
    }
}
